## MobileNet

[mobilenet](https://arxiv.org/abs/1704.04861)은 적은 파라미터로 효율적인 모델을 만들기 위해 노력한 논문입니다.

